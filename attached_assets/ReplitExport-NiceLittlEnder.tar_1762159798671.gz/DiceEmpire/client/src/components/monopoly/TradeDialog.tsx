import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useMonopoly } from '@/lib/stores/useMonopoly';

export function TradeDialog() {
  const showTradeDialog = useMonopoly(state => state.showTradeDialog);
  const currentTrade = useMonopoly(state => state.currentTrade);
  const players = useMonopoly(state => state.players);
  const currentPlayerIndex = useMonopoly(state => state.currentPlayerIndex);
  const boardSpaces = useMonopoly(state => state.boardSpaces);
  const acceptTrade = useMonopoly(state => state.acceptTrade);
  const rejectTrade = useMonopoly(state => state.rejectTrade);

  const [toPlayerId, setToPlayerId] = useState<number | null>(null);
  const [offeredMoney, setOfferedMoney] = useState(0);
  const [requestedMoney, setRequestedMoney] = useState(0);
  const [offeredProperties, setOfferedProperties] = useState<number[]>([]);
  const [requestedProperties, setRequestedProperties] = useState<number[]>([]);

  if (!showTradeDialog && !currentTrade) return null;

  const currentPlayer = players[currentPlayerIndex];

  const handleCreateTrade = () => {
    if (toPlayerId === null) return;

    useMonopoly.getState().createTrade({
      fromPlayer: currentPlayer.id,
      toPlayer: toPlayerId,
      offeredProperties,
      requestedProperties,
      offeredMoney,
      requestedMoney,
    });
  };

  const handleClose = () => {
    useMonopoly.setState({ showTradeDialog: false });
    setToPlayerId(null);
    setOfferedMoney(0);
    setRequestedMoney(0);
    setOfferedProperties([]);
    setRequestedProperties([]);
  };

  if (currentTrade) {
    const fromPlayer = players.find(p => p.id === currentTrade.fromPlayer);
    const toPlayer = players.find(p => p.id === currentTrade.toPlayer);

    return (
      <div className="fixed inset-0 flex items-center justify-center bg-black/50 z-50">
        <Card className="w-full max-w-lg bg-white shadow-2xl">
          <CardHeader>
            <CardTitle>Trade Offer</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="text-center">
              <p className="font-semibold">
                {fromPlayer?.username} wants to trade with {toPlayer?.username}
              </p>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label className="font-semibold">Offering:</Label>
                {currentTrade.offeredMoney > 0 && <div>${currentTrade.offeredMoney}</div>}
                {currentTrade.offeredProperties.map(propId => (
                  <div key={propId} className="text-sm">
                    {boardSpaces[propId].name}
                  </div>
                ))}
              </div>

              <div className="space-y-2">
                <Label className="font-semibold">Requesting:</Label>
                {currentTrade.requestedMoney > 0 && <div>${currentTrade.requestedMoney}</div>}
                {currentTrade.requestedProperties.map(propId => (
                  <div key={propId} className="text-sm">
                    {boardSpaces[propId].name}
                  </div>
                ))}
              </div>
            </div>

            <div className="flex gap-2">
              <Button onClick={acceptTrade} className="flex-1">
                Accept
              </Button>
              <Button onClick={rejectTrade} variant="outline" className="flex-1">
                Reject
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 flex items-center justify-center bg-black/50 z-50">
      <Card className="w-full max-w-2xl bg-white shadow-2xl max-h-[90vh] overflow-auto">
        <CardHeader>
          <CardTitle>Create Trade</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label>Trade With:</Label>
            <Select onValueChange={(value) => setToPlayerId(parseInt(value))}>
              <SelectTrigger>
                <SelectValue placeholder="Select player" />
              </SelectTrigger>
              <SelectContent>
                {players
                  .filter(p => p.id !== currentPlayer.id && !p.isBankrupt)
                  .map(player => (
                    <SelectItem key={player.id} value={player.id.toString()}>
                      {player.username}
                    </SelectItem>
                  ))}
              </SelectContent>
            </Select>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Your Offer:</Label>
              <Input
                type="number"
                placeholder="Money amount"
                value={offeredMoney}
                onChange={(e) => setOfferedMoney(parseInt(e.target.value) || 0)}
              />
            </div>

            <div className="space-y-2">
              <Label>Your Request:</Label>
              <Input
                type="number"
                placeholder="Money amount"
                value={requestedMoney}
                onChange={(e) => setRequestedMoney(parseInt(e.target.value) || 0)}
              />
            </div>
          </div>

          <div className="flex gap-2">
            <Button onClick={handleCreateTrade} disabled={toPlayerId === null}>
              Propose Trade
            </Button>
            <Button onClick={handleClose} variant="outline">
              Cancel
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
