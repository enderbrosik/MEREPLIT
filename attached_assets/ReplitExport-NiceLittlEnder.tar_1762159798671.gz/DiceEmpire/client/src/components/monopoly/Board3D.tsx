import { useRef } from 'react';
import { Text } from '@react-three/drei';
import * as THREE from 'three';
import { useMonopoly } from '@/lib/stores/useMonopoly';

export function Board3D() {
  const boardSpaces = useMonopoly(state => state.boardSpaces);
  const properties = useMonopoly(state => state.properties);
  
  const boardSize = 15;
  const spaceWidth = 1.5;
  const spaceHeight = 1.2;

  return (
    <group>
      {/* Center area */}
      <mesh position={[0, -0.05, 0]} rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
        <planeGeometry args={[boardSize - 3, boardSize - 3]} />
        <meshStandardMaterial color="#d4e7d4" />
      </mesh>

      {/* Board spaces */}
      {boardSpaces.map((space, index) => {
        const property = properties.get(space.id);
        const isCorner = index % 10 === 0;
        const size = isCorner ? 1.8 : spaceWidth;

        return (
          <group key={space.id} position={space.position}>
            {/* Space base */}
            <mesh position={[0, 0, 0]} receiveShadow>
              <boxGeometry args={[size, 0.1, size]} />
              <meshStandardMaterial color={space.color || '#f0f0f0'} />
            </mesh>

            {/* Property color stripe */}
            {space.type === 'property' && space.color && (
              <mesh position={[0, 0.06, 0]} receiveShadow>
                <boxGeometry args={[size * 0.9, 0.12, size * 0.3]} />
                <meshStandardMaterial color={space.color} />
              </mesh>
            )}

            {/* Space name */}
            <Text
              position={[0, 0.12, 0]}
              rotation={[-Math.PI / 2, 0, getTextRotation(index)]}
              fontSize={0.15}
              color="black"
              anchorX="center"
              anchorY="middle"
              maxWidth={size * 0.9}
            >
              {space.name}
            </Text>

            {/* Property details */}
            {space.price && (
              <Text
                position={[0, 0.13, -size * 0.3]}
                rotation={[-Math.PI / 2, 0, getTextRotation(index)]}
                fontSize={0.12}
                color="#006400"
                anchorX="center"
                anchorY="middle"
              >
                ${space.price}
              </Text>
            )}

            {/* Houses */}
            {property && property.houses > 0 && !property.hasHotel && (
              <group>
                {Array.from({ length: property.houses }).map((_, i) => (
                  <mesh
                    key={i}
                    position={[-0.4 + i * 0.25, 0.25, 0]}
                    castShadow
                  >
                    <boxGeometry args={[0.15, 0.3, 0.15]} />
                    <meshStandardMaterial color="#00ff00" />
                  </mesh>
                ))}
              </group>
            )}

            {/* Hotel */}
            {property && property.hasHotel && (
              <mesh position={[0, 0.35, 0]} castShadow>
                <boxGeometry args={[0.4, 0.5, 0.4]} />
                <meshStandardMaterial color="#ff0000" />
              </mesh>
            )}

            {/* Mortgaged indicator */}
            {property && property.isMortgaged && (
              <mesh position={[0, 0.14, 0]} rotation={[-Math.PI / 2, 0, Math.PI / 4]}>
                <planeGeometry args={[size * 0.8, size * 0.8]} />
                <meshStandardMaterial color="#000000" opacity={0.3} transparent />
              </mesh>
            )}

            {/* Corner space icons */}
            {isCorner && renderCornerIcon(space.type, space.id)}
          </group>
        );
      })}

      {/* Board border */}
      <mesh position={[0, -0.1, 0]} rotation={[-Math.PI / 2, 0, 0]}>
        <ringGeometry args={[boardSize / 2 - 0.5, boardSize / 2, 4]} />
        <meshStandardMaterial color="#8B4513" />
      </mesh>
    </group>
  );
}

function getTextRotation(index: number): number {
  if (index >= 0 && index < 10) return 0;
  if (index >= 10 && index < 20) return Math.PI / 2;
  if (index >= 20 && index < 30) return Math.PI;
  return -Math.PI / 2;
}

function renderCornerIcon(type: string, id: number) {
  switch (id) {
    case 0: // GO
      return (
        <mesh position={[0, 0.15, 0]}>
          <cylinderGeometry args={[0.5, 0.5, 0.1, 32]} />
          <meshStandardMaterial color="#32CD32" />
        </mesh>
      );
    case 10: // Jail
      return (
        <mesh position={[0, 0.15, 0]}>
          <boxGeometry args={[0.8, 0.1, 0.8]} />
          <meshStandardMaterial color="#696969" />
        </mesh>
      );
    case 20: // Free Parking
      return (
        <mesh position={[0, 0.15, 0]}>
          <torusGeometry args={[0.4, 0.1, 16, 32]} />
          <meshStandardMaterial color="#4169E1" />
        </mesh>
      );
    case 30: // Go To Jail
      return (
        <mesh position={[0, 0.15, 0]}>
          <boxGeometry args={[0.6, 0.2, 0.6]} />
          <meshStandardMaterial color="#DC143C" />
        </mesh>
      );
    default:
      return null;
  }
}
