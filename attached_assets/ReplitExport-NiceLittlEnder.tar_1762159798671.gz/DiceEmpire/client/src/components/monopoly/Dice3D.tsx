import { useRef, useEffect, useState } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import { useMonopoly } from '@/lib/stores/useMonopoly';

interface DicePhysics {
  velocity: THREE.Vector3;
  angularVelocity: THREE.Vector3;
  position: THREE.Vector3;
  rotation: THREE.Euler;
}

export function Dice3D() {
  const diceValues = useMonopoly(state => state.diceValues);
  const isRolling = useMonopoly(state => state.isRolling);
  
  const dice1GroupRef = useRef<THREE.Group>(null);
  const dice2GroupRef = useRef<THREE.Group>(null);
  
  const [dice1Physics, setDice1Physics] = useState<DicePhysics>({
    velocity: new THREE.Vector3(0, 0, 0),
    angularVelocity: new THREE.Vector3(0, 0, 0),
    position: new THREE.Vector3(-0.8, 0, 0),
    rotation: new THREE.Euler(0, 0, 0),
  });
  
  const [dice2Physics, setDice2Physics] = useState<DicePhysics>({
    velocity: new THREE.Vector3(0, 0, 0),
    angularVelocity: new THREE.Vector3(0, 0, 0),
    position: new THREE.Vector3(0.8, 0, 0),
    rotation: new THREE.Euler(0, 0, 0),
  });
  
  const rollStartTime = useRef(0);
  const targetRotation1 = useRef(new THREE.Euler(0, 0, 0));
  const targetRotation2 = useRef(new THREE.Euler(0, 0, 0));

  useEffect(() => {
    if (isRolling) {
      rollStartTime.current = Date.now();
      
      // Initialize physics with random impulse
      setDice1Physics({
        velocity: new THREE.Vector3(
          (Math.random() - 0.5) * 2,
          3 + Math.random() * 2,
          (Math.random() - 0.5) * 2
        ),
        angularVelocity: new THREE.Vector3(
          (Math.random() - 0.5) * 20,
          (Math.random() - 0.5) * 20,
          (Math.random() - 0.5) * 20
        ),
        position: new THREE.Vector3(-0.8, 0, 0),
        rotation: new THREE.Euler(
          Math.random() * Math.PI,
          Math.random() * Math.PI,
          Math.random() * Math.PI
        ),
      });
      
      setDice2Physics({
        velocity: new THREE.Vector3(
          (Math.random() - 0.5) * 2,
          3 + Math.random() * 2,
          (Math.random() - 0.5) * 2
        ),
        angularVelocity: new THREE.Vector3(
          (Math.random() - 0.5) * 20,
          (Math.random() - 0.5) * 20,
          (Math.random() - 0.5) * 20
        ),
        position: new THREE.Vector3(0.8, 0, 0),
        rotation: new THREE.Euler(
          Math.random() * Math.PI,
          Math.random() * Math.PI,
          Math.random() * Math.PI
        ),
      });
    } else {
      // Set target rotations when not rolling
      targetRotation1.current = getDiceRotationForValue(diceValues[0]);
      targetRotation2.current = getDiceRotationForValue(diceValues[1]);
    }
  }, [isRolling, diceValues]);

  useFrame((state, delta) => {
    if (isRolling) {
      const elapsed = (Date.now() - rollStartTime.current) / 1000;
      const rollDuration = 1.5; // seconds
      
      if (elapsed < rollDuration) {
        // Physics simulation during roll
        const gravity = new THREE.Vector3(0, -9.8, 0);
        const damping = 0.95; // Angular velocity damping
        const friction = 0.98; // Linear velocity damping
        
        // Update dice 1
        setDice1Physics(prev => {
          const newVelocity = prev.velocity.clone().add(gravity.clone().multiplyScalar(delta));
          newVelocity.multiplyScalar(friction);
          
          const newPosition = prev.position.clone().add(newVelocity.clone().multiplyScalar(delta));
          
          // Ground collision
          if (newPosition.y < 0.3) {
            newPosition.y = 0.3;
            newVelocity.y = -newVelocity.y * 0.4; // Bounce with energy loss
            newVelocity.x *= 0.7;
            newVelocity.z *= 0.7;
          }
          
          // Boundaries
          if (Math.abs(newPosition.x) > 2) newVelocity.x = -newVelocity.x * 0.5;
          if (Math.abs(newPosition.z) > 2) newVelocity.z = -newVelocity.z * 0.5;
          
          const newAngularVelocity = prev.angularVelocity.clone().multiplyScalar(damping);
          const newRotation = new THREE.Euler(
            prev.rotation.x + newAngularVelocity.x * delta,
            prev.rotation.y + newAngularVelocity.y * delta,
            prev.rotation.z + newAngularVelocity.z * delta
          );
          
          return {
            velocity: newVelocity,
            angularVelocity: newAngularVelocity,
            position: newPosition,
            rotation: newRotation,
          };
        });
        
        // Update dice 2
        setDice2Physics(prev => {
          const newVelocity = prev.velocity.clone().add(gravity.clone().multiplyScalar(delta));
          newVelocity.multiplyScalar(friction);
          
          const newPosition = prev.position.clone().add(newVelocity.clone().multiplyScalar(delta));
          
          // Ground collision
          if (newPosition.y < 0.3) {
            newPosition.y = 0.3;
            newVelocity.y = -newVelocity.y * 0.4;
            newVelocity.x *= 0.7;
            newVelocity.z *= 0.7;
          }
          
          // Boundaries
          if (Math.abs(newPosition.x) > 2) newVelocity.x = -newVelocity.x * 0.5;
          if (Math.abs(newPosition.z) > 2) newVelocity.z = -newVelocity.z * 0.5;
          
          const newAngularVelocity = prev.angularVelocity.clone().multiplyScalar(damping);
          const newRotation = new THREE.Euler(
            prev.rotation.x + newAngularVelocity.x * delta,
            prev.rotation.y + newAngularVelocity.y * delta,
            prev.rotation.z + newAngularVelocity.z * delta
          );
          
          return {
            velocity: newVelocity,
            angularVelocity: newAngularVelocity,
            position: newPosition,
            rotation: newRotation,
          };
        });
      }
    } else {
      // Smoothly interpolate to final position and rotation when stopped
      setDice1Physics(prev => ({
        ...prev,
        position: prev.position.clone().lerp(new THREE.Vector3(-0.8, 0, 0), 0.1),
        rotation: new THREE.Euler(
          prev.rotation.x + (targetRotation1.current.x - prev.rotation.x) * 0.1,
          prev.rotation.y + (targetRotation1.current.y - prev.rotation.y) * 0.1,
          prev.rotation.z + (targetRotation1.current.z - prev.rotation.z) * 0.1
        ),
      }));
      
      setDice2Physics(prev => ({
        ...prev,
        position: prev.position.clone().lerp(new THREE.Vector3(0.8, 0, 0), 0.1),
        rotation: new THREE.Euler(
          prev.rotation.x + (targetRotation2.current.x - prev.rotation.x) * 0.1,
          prev.rotation.y + (targetRotation2.current.y - prev.rotation.y) * 0.1,
          prev.rotation.z + (targetRotation2.current.z - prev.rotation.z) * 0.1
        ),
      }));
    }
    
    // Apply physics to groups (both dice and pips move together)
    if (dice1GroupRef.current) {
      dice1GroupRef.current.position.copy(dice1Physics.position);
      dice1GroupRef.current.rotation.copy(dice1Physics.rotation);
    }
    
    if (dice2GroupRef.current) {
      dice2GroupRef.current.position.copy(dice2Physics.position);
      dice2GroupRef.current.rotation.copy(dice2Physics.rotation);
    }
  });

  return (
    <group position={[0, 3, -5]}>
      {/* Dice 1 - pips are children so they rotate with the cube */}
      <group ref={dice1GroupRef}>
        <mesh castShadow>
          <boxGeometry args={[0.6, 0.6, 0.6]} />
          <meshStandardMaterial color="#ffffff" />
        </mesh>
        {renderAllDots(diceValues[0])}
      </group>

      {/* Dice 2 - pips are children so they rotate with the cube */}
      <group ref={dice2GroupRef}>
        <mesh castShadow>
          <boxGeometry args={[0.6, 0.6, 0.6]} />
          <meshStandardMaterial color="#ffffff" />
        </mesh>
        {renderAllDots(diceValues[1])}
      </group>
    </group>
  );
}

function getDiceRotationForValue(value: number): THREE.Euler {
  switch (value) {
    case 1: return new THREE.Euler(0, 0, 0);
    case 2: return new THREE.Euler(0, 0, Math.PI / 2);
    case 3: return new THREE.Euler(0, Math.PI / 2, 0);
    case 4: return new THREE.Euler(0, -Math.PI / 2, 0);
    case 5: return new THREE.Euler(0, 0, -Math.PI / 2);
    case 6: return new THREE.Euler(Math.PI, 0, 0);
    default: return new THREE.Euler(0, 0, 0);
  }
}

// Render dots on all 6 faces of the die
function renderAllDots(currentValue: number) {
  const dotSize = 0.08;
  const offset = 0.31;
  
  // Define all 6 faces with their dots
  const faces = [
    { value: 1, normal: [0, 1, 0], rotation: [0, 0, 0] },      // Top
    { value: 6, normal: [0, -1, 0], rotation: [Math.PI, 0, 0] }, // Bottom
    { value: 2, normal: [0, 0, 1], rotation: [Math.PI / 2, 0, 0] },  // Front
    { value: 5, normal: [0, 0, -1], rotation: [-Math.PI / 2, 0, 0] }, // Back
    { value: 3, normal: [1, 0, 0], rotation: [0, 0, -Math.PI / 2] },  // Right
    { value: 4, normal: [-1, 0, 0], rotation: [0, 0, Math.PI / 2] },  // Left
  ];
  
  return (
    <>
      {faces.map((face, faceIndex) => (
        <group key={faceIndex}>
          {getDotPositionsForFace(face.value, face.normal as [number, number, number]).map((pos, i) => (
            <mesh key={i} position={pos}>
              <sphereGeometry args={[dotSize, 8, 8]} />
              <meshStandardMaterial color="#000000" />
            </mesh>
          ))}
        </group>
      ))}
    </>
  );
}

function getDotPositionsForFace(value: number, normal: [number, number, number]): [number, number, number][] {
  const offset = 0.31;
  const corner = 0.15;
  
  // Get base positions for this value
  const basePositions = getDotPattern(value);
  
  // Transform positions based on face normal
  return basePositions.map(([x, y]) => {
    if (normal[1] !== 0) {
      // Top or bottom face (Y normal)
      return [x, normal[1] * offset, y] as [number, number, number];
    } else if (normal[0] !== 0) {
      // Left or right face (X normal)
      return [normal[0] * offset, y, -x] as [number, number, number];
    } else {
      // Front or back face (Z normal)
      return [x, y, normal[2] * offset] as [number, number, number];
    }
  });
}

function getDotPattern(value: number): [number, number][] {
  const corner = 0.15;
  const mid = 0;

  switch (value) {
    case 1:
      return [[mid, mid]];
    case 2:
      return [[-corner, -corner], [corner, corner]];
    case 3:
      return [[-corner, -corner], [mid, mid], [corner, corner]];
    case 4:
      return [
        [-corner, -corner], [corner, -corner],
        [-corner, corner], [corner, corner]
      ];
    case 5:
      return [
        [-corner, -corner], [corner, -corner],
        [mid, mid],
        [-corner, corner], [corner, corner]
      ];
    case 6:
      return [
        [-corner, -corner], [corner, -corner],
        [-corner, mid], [corner, mid],
        [-corner, corner], [corner, corner]
      ];
    default:
      return [[mid, mid]];
  }
}
