import { useRef, useEffect } from 'react';
import { useFrame, useThree } from '@react-three/fiber';
import { OrbitControls } from '@react-three/drei';
import { useMonopoly } from '@/lib/stores/useMonopoly';
import * as THREE from 'three';

export function CameraController() {
  const { camera } = useThree();
  const controlsRef = useRef<any>(null);
  const currentPlayerIndex = useMonopoly(state => state.currentPlayerIndex);
  const players = useMonopoly(state => state.players);
  const boardSpaces = useMonopoly(state => state.boardSpaces);

  useEffect(() => {
    const currentPlayer = players[currentPlayerIndex];
    if (currentPlayer) {
      const space = boardSpaces[currentPlayer.position];
      if (space) {
        const targetPosition = new THREE.Vector3(
          space.position[0],
          space.position[1] + 5,
          space.position[2] + 8
        );
        
        camera.position.lerp(targetPosition, 0.1);
        
        if (controlsRef.current) {
          controlsRef.current.target.set(space.position[0], 0, space.position[2]);
        }
      }
    }
  }, [currentPlayerIndex, players, boardSpaces, camera]);

  return (
    <OrbitControls
      ref={controlsRef}
      enableDamping
      dampingFactor={0.05}
      minDistance={10}
      maxDistance={30}
      maxPolarAngle={Math.PI / 2}
      target={[0, 0, 0]}
    />
  );
}
