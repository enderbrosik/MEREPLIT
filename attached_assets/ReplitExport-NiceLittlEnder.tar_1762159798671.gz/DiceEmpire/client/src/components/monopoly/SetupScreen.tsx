import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { useMonopoly } from '@/lib/stores/useMonopoly';

export function SetupScreen() {
  const [numPlayers, setNumPlayers] = useState(4);
  const [playerNames, setPlayerNames] = useState<string[]>(
    Array.from({ length: 4 }, (_, i) => `Player ${i + 1}`)
  );
  const setupGame = useMonopoly(state => state.setupGame);

  const handleNumPlayersChange = (num: number) => {
    // Clamp between 2 and 40
    const clampedNum = Math.min(Math.max(num, 2), 40);
    setNumPlayers(clampedNum);
    const names = Array.from({ length: clampedNum }, (_, i) =>
      i < playerNames.length ? playerNames[i] : `Player ${i + 1}`
    );
    setPlayerNames(names);
  };

  const handleNameChange = (index: number, name: string) => {
    const newNames = [...playerNames];
    newNames[index] = name;
    setPlayerNames(newNames);
  };

  const handleStart = () => {
    if (playerNames.every(name => name.trim())) {
      setupGame(playerNames);
    }
  };

  return (
    <div className="fixed inset-0 flex items-center justify-center bg-gradient-to-br from-green-900 via-green-700 to-green-900 z-50">
      <Card className="w-full max-w-4xl max-h-[90vh] overflow-auto bg-white/95 backdrop-blur">
        <CardHeader>
          <CardTitle className="text-4xl font-bold text-center text-green-800">
            3D Monopoly Game
          </CardTitle>
          <p className="text-center text-gray-600 mt-2">
            Advanced multiplayer board game with full Monopoly rules
          </p>
        </CardHeader>
        <CardContent className="space-y-6">
          <div>
            <Label className="text-lg font-semibold mb-3 block">Number of Players (2-40)</Label>
            <div className="flex gap-2 items-center">
              <Input
                type="number"
                min={2}
                max={40}
                value={numPlayers}
                onChange={(e) => handleNumPlayersChange(parseInt(e.target.value) || 2)}
                className="w-24 text-lg"
              />
              <div className="flex gap-2">
                {[2, 4, 6, 8].map(num => (
                  <Button
                    key={num}
                    onClick={() => handleNumPlayersChange(num)}
                    variant={numPlayers === num ? "default" : "outline"}
                    size="sm"
                  >
                    {num}
                  </Button>
                ))}
              </div>
            </div>
          </div>

          <div>
            <Label className="text-lg font-semibold mb-3 block">Player Names</Label>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 max-h-[400px] overflow-y-auto">
              {playerNames.map((name, i) => (
                <div key={i} className="flex items-center gap-2">
                  <div
                    className="w-8 h-8 rounded-full flex-shrink-0"
                    style={{ backgroundColor: getPieceColor(i) }}
                  />
                  <Input
                    value={name}
                    onChange={(e) => handleNameChange(i, e.target.value)}
                    placeholder={`Player ${i + 1}`}
                    className="flex-1"
                  />
                </div>
              ))}
            </div>
          </div>

          <div className="bg-blue-50 p-4 rounded-lg">
            <h3 className="font-semibold text-blue-900 mb-2">Game Features:</h3>
            <ul className="text-sm text-blue-800 space-y-1">
              <li>✓ Full 3D graphics with animated dice and player pieces</li>
              <li>✓ Complete Monopoly rules: properties, rent, houses, hotels</li>
              <li>✓ Chance and Community Chest cards</li>
              <li>✓ Jail mechanics and bankruptcy system</li>
              <li>✓ Trading between players</li>
              <li>✓ Advanced camera controls and smooth animations</li>
            </ul>
          </div>

          <Button
            onClick={handleStart}
            size="lg"
            className="w-full text-xl py-6 bg-green-600 hover:bg-green-700"
            disabled={!playerNames.every(name => name.trim())}
          >
            Start Game
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}

function getPieceColor(index: number): string {
  const colors = [
    '#FF0000', '#00FF00', '#0000FF', '#FFFF00', '#FF00FF', '#00FFFF',
    '#FF8000', '#8000FF', '#FF0080', '#80FF00', '#FF4040', '#4040FF',
    '#40FF40', '#FFFF40', '#FF40FF', '#40FFFF', '#FFA040', '#A040FF',
    '#FF4080', '#A0FF40', '#804040', '#408080', '#804080', '#808040',
    '#FF8080', '#8080FF', '#80FF80', '#FFFF80', '#FF80FF', '#80FFFF',
    '#FFC080', '#C080FF', '#FFC0C0', '#C0FFC0', '#C0C0FF', '#FFFFC0',
    '#FFC0FF', '#C0FFFF', '#A0A0A0', '#404040'
  ];
  return colors[index % colors.length];
}
