import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { useMonopoly } from '@/lib/stores/useMonopoly';
import { PropertyCard } from './PropertyCard';
import { TradeDialog } from './TradeDialog';

export function GameUI() {
  const players = useMonopoly(state => state.players);
  const currentPlayerIndex = useMonopoly(state => state.currentPlayerIndex);
  const diceValues = useMonopoly(state => state.diceValues);
  const isRolling = useMonopoly(state => state.isRolling);
  const message = useMonopoly(state => state.message);
  const transactionLog = useMonopoly(state => state.transactionLog);
  const rollDice = useMonopoly(state => state.rollDice);
  const endTurn = useMonopoly(state => state.endTurn);
  const gamePhase = useMonopoly(state => state.gamePhase);

  const currentPlayer = players[currentPlayerIndex];

  if (gamePhase === 'ended') {
    return (
      <div className="fixed inset-0 flex items-center justify-center bg-black/70 z-50">
        <Card className="bg-white/95 backdrop-blur">
          <CardHeader>
            <CardTitle className="text-3xl text-center">Game Over!</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-xl text-center">
              {players.find(p => p.isActive)?.username} wins!
            </p>
            <Button
              onClick={() => useMonopoly.getState().resetGame()}
              size="lg"
              className="w-full"
            >
              New Game
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <>
      <PropertyCard />
      <TradeDialog />

      {/* Current Player Info - Top Center */}
      <div className="fixed top-4 left-1/2 transform -translate-x-1/2 z-40">
        <Card className="bg-white/90 backdrop-blur shadow-xl">
          <CardHeader className="pb-2">
            <CardTitle className="text-center">
              <div className="flex items-center justify-center gap-2">
                <div
                  className="w-6 h-6 rounded-full"
                  style={{ backgroundColor: currentPlayer?.color }}
                />
                <span>{currentPlayer?.username}'s Turn</span>
              </div>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            <div className="flex gap-4 justify-center text-lg font-semibold">
              <div className="text-green-600">💰 ${currentPlayer?.money}</div>
              <div className="text-blue-600">🏠 {currentPlayer?.properties.length}</div>
              {currentPlayer?.getOutOfJailCards > 0 && (
                <div className="text-yellow-600">🎫 {currentPlayer.getOutOfJailCards}</div>
              )}
            </div>
            {currentPlayer?.inJail && (
              <div className="text-red-600 text-center font-semibold">
                In Jail ({currentPlayer.jailTurns}/3 turns)
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Dice Display and Controls - Top Right */}
      <div className="fixed top-4 right-4 z-40 space-y-2">
        <Card className="bg-white/90 backdrop-blur shadow-xl">
          <CardContent className="p-4">
            <div className="flex gap-2 items-center justify-center mb-3">
              <div className="w-16 h-16 bg-white border-2 border-gray-800 rounded-lg flex items-center justify-center text-2xl font-bold">
                {diceValues[0]}
              </div>
              <div className="w-16 h-16 bg-white border-2 border-gray-800 rounded-lg flex items-center justify-center text-2xl font-bold">
                {diceValues[1]}
              </div>
            </div>
            <div className="space-y-2">
              <Button
                onClick={rollDice}
                disabled={isRolling}
                className="w-full"
                size="lg"
              >
                {isRolling ? 'Rolling...' : 'Roll Dice'}
              </Button>
              {currentPlayer && !currentPlayer.inJail && (
                <>
                  <Button
                    onClick={() => useMonopoly.getState().payJailBail(currentPlayer.id)}
                    variant="outline"
                    className="w-full"
                    size="sm"
                    disabled={currentPlayer.money < 50}
                  >
                    Pay Bail ($50)
                  </Button>
                  {currentPlayer.getOutOfJailCards > 0 && (
                    <Button
                      onClick={() => useMonopoly.getState().useGetOutOfJailCard(currentPlayer.id)}
                      variant="outline"
                      className="w-full"
                      size="sm"
                    >
                      Use Jail Card
                    </Button>
                  )}
                </>
              )}
              <Button
                onClick={endTurn}
                variant="secondary"
                className="w-full"
                size="sm"
                disabled={isRolling}
              >
                End Turn
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Message Display - Bottom Center */}
      {message && (
        <div className="fixed bottom-4 left-1/2 transform -translate-x-1/2 z-40">
          <Card className="bg-blue-600 text-white shadow-xl">
            <CardContent className="p-3">
              <p className="text-center font-semibold">{message}</p>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Player List - Left Side */}
      <div className="fixed left-4 top-1/2 transform -translate-y-1/2 z-40 max-h-[80vh] overflow-hidden">
        <Card className="bg-white/90 backdrop-blur shadow-xl">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm">Players</CardTitle>
          </CardHeader>
          <CardContent>
            <ScrollArea className="max-h-[60vh]">
              <div className="space-y-2">
                {players.map((player, index) => (
                  <div
                    key={player.id}
                    className={`p-2 rounded ${
                      index === currentPlayerIndex
                        ? 'bg-blue-100 border-2 border-blue-500'
                        : player.isBankrupt
                        ? 'bg-gray-100 opacity-50'
                        : 'bg-gray-50'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <div
                        className="w-4 h-4 rounded-full"
                        style={{ backgroundColor: player.color }}
                      />
                      <div className="flex-1 min-w-0">
                        <div className="font-semibold text-sm truncate">
                          {player.username}
                        </div>
                        <div className="text-xs text-gray-600">
                          ${player.money} • {player.properties.length} props
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </ScrollArea>
          </CardContent>
        </Card>
      </div>

      {/* Transaction Log - Bottom Right */}
      <div className="fixed bottom-4 right-4 z-40 w-80">
        <Card className="bg-white/90 backdrop-blur shadow-xl">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm">Activity Log</CardTitle>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-40">
              <div className="space-y-1">
                {transactionLog.map((log, i) => (
                  <div key={i} className="text-xs text-gray-700 border-b border-gray-200 pb-1">
                    {log}
                  </div>
                ))}
              </div>
            </ScrollArea>
          </CardContent>
        </Card>
      </div>
    </>
  );
}
