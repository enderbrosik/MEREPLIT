import { useRef, useEffect } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import { Player } from '@/lib/stores/useMonopoly';

interface PlayerPiece3DProps {
  player: Player;
  position: [number, number, number];
  offset: number;
}

export function PlayerPiece3D({ player, position, offset }: PlayerPiece3DProps) {
  const meshRef = useRef<THREE.Group>(null);
  const targetPosition = useRef(new THREE.Vector3(...position));
  
  useEffect(() => {
    targetPosition.current.set(
      position[0] + Math.cos(offset) * 0.3,
      position[1] + 0.3,
      position[2] + Math.sin(offset) * 0.3
    );
  }, [position, offset]);

  useFrame(() => {
    if (meshRef.current) {
      meshRef.current.position.lerp(targetPosition.current, 0.1);
      meshRef.current.rotation.y += 0.02;
    }
  });

  return (
    <group ref={meshRef} castShadow>
      {getPieceGeometry(player.pieceType, player.color)}
    </group>
  );
}

function getPieceGeometry(type: number, color: string) {
  const size = 0.25;
  
  // 40 unique piece designs
  switch (type) {
    case 0: // Simple Cube
      return (
        <mesh castShadow>
          <boxGeometry args={[size, size, size]} />
          <meshStandardMaterial color={color} metalness={0.3} roughness={0.4} />
        </mesh>
      );
    
    case 1: // Sphere
      return (
        <mesh castShadow>
          <sphereGeometry args={[size * 0.6, 16, 16]} />
          <meshStandardMaterial color={color} metalness={0.5} roughness={0.3} />
        </mesh>
      );
    
    case 2: // Pyramid
      return (
        <mesh castShadow>
          <coneGeometry args={[size * 0.6, size * 1.2, 4]} />
          <meshStandardMaterial color={color} metalness={0.2} roughness={0.6} />
        </mesh>
      );
    
    case 3: // Cylinder
      return (
        <mesh castShadow>
          <cylinderGeometry args={[size * 0.4, size * 0.4, size * 1.2, 16]} />
          <meshStandardMaterial color={color} metalness={0.4} roughness={0.5} />
        </mesh>
      );
    
    case 4: // Cone
      return (
        <mesh castShadow>
          <coneGeometry args={[size * 0.5, size * 1.2, 16]} />
          <meshStandardMaterial color={color} metalness={0.3} roughness={0.4} />
        </mesh>
      );
    
    case 5: // Torus
      return (
        <mesh castShadow>
          <torusGeometry args={[size * 0.5, size * 0.2, 16, 32]} />
          <meshStandardMaterial color={color} metalness={0.6} roughness={0.2} />
        </mesh>
      );
    
    case 6: // Octahedron
      return (
        <mesh castShadow>
          <octahedronGeometry args={[size * 0.7]} />
          <meshStandardMaterial color={color} metalness={0.4} roughness={0.4} />
        </mesh>
      );
    
    case 7: // Dodecahedron
      return (
        <mesh castShadow>
          <dodecahedronGeometry args={[size * 0.6]} />
          <meshStandardMaterial color={color} metalness={0.5} roughness={0.3} />
        </mesh>
      );
    
    case 8: // Tetrahedron
      return (
        <mesh castShadow>
          <tetrahedronGeometry args={[size * 0.8]} />
          <meshStandardMaterial color={color} metalness={0.3} roughness={0.5} />
        </mesh>
      );
    
    case 9: // Icosahedron
      return (
        <mesh castShadow>
          <icosahedronGeometry args={[size * 0.6]} />
          <meshStandardMaterial color={color} metalness={0.4} roughness={0.4} />
        </mesh>
      );
    
    case 10: // Tall Box
      return (
        <mesh castShadow>
          <boxGeometry args={[size * 0.6, size * 1.4, size * 0.6]} />
          <meshStandardMaterial color={color} metalness={0.3} roughness={0.4} />
        </mesh>
      );
    
    case 11: // Wide Box
      return (
        <mesh castShadow>
          <boxGeometry args={[size * 1.2, size * 0.6, size * 0.6]} />
          <meshStandardMaterial color={color} metalness={0.3} roughness={0.4} />
        </mesh>
      );
    
    case 12: // Capsule (Cylinder + Spheres)
      return (
        <group>
          <mesh castShadow position={[0, 0, 0]}>
            <cylinderGeometry args={[size * 0.3, size * 0.3, size * 0.8, 16]} />
            <meshStandardMaterial color={color} metalness={0.4} roughness={0.3} />
          </mesh>
          <mesh castShadow position={[0, size * 0.4, 0]}>
            <sphereGeometry args={[size * 0.3, 16, 16]} />
            <meshStandardMaterial color={color} metalness={0.4} roughness={0.3} />
          </mesh>
          <mesh castShadow position={[0, -size * 0.4, 0]}>
            <sphereGeometry args={[size * 0.3, 16, 16]} />
            <meshStandardMaterial color={color} metalness={0.4} roughness={0.3} />
          </mesh>
        </group>
      );
    
    case 13: // Double Pyramid
      return (
        <group>
          <mesh castShadow position={[0, size * 0.3, 0]} rotation={[0, 0, 0]}>
            <coneGeometry args={[size * 0.5, size * 0.6, 4]} />
            <meshStandardMaterial color={color} metalness={0.3} roughness={0.4} />
          </mesh>
          <mesh castShadow position={[0, -size * 0.3, 0]} rotation={[Math.PI, 0, 0]}>
            <coneGeometry args={[size * 0.5, size * 0.6, 4]} />
            <meshStandardMaterial color={color} metalness={0.3} roughness={0.4} />
          </mesh>
        </group>
      );
    
    case 14: // Ring with Center
      return (
        <group>
          <mesh castShadow>
            <torusGeometry args={[size * 0.6, size * 0.15, 16, 32]} />
            <meshStandardMaterial color={color} metalness={0.5} roughness={0.3} />
          </mesh>
          <mesh castShadow>
            <sphereGeometry args={[size * 0.25, 16, 16]} />
            <meshStandardMaterial color={color} metalness={0.5} roughness={0.3} />
          </mesh>
        </group>
      );
    
    case 15: // Star (Octahedron + Smaller octahedron)
      return (
        <group>
          <mesh castShadow>
            <octahedronGeometry args={[size * 0.7]} />
            <meshStandardMaterial color={color} metalness={0.4} roughness={0.3} />
          </mesh>
          <mesh castShadow rotation={[0, Math.PI / 4, 0]}>
            <octahedronGeometry args={[size * 0.4]} />
            <meshStandardMaterial color={color} metalness={0.6} roughness={0.2} />
          </mesh>
        </group>
      );
    
    case 16: // Tri-Stack
      return (
        <group>
          <mesh castShadow position={[0, -size * 0.4, 0]}>
            <boxGeometry args={[size * 0.8, size * 0.4, size * 0.8]} />
            <meshStandardMaterial color={color} metalness={0.3} roughness={0.4} />
          </mesh>
          <mesh castShadow position={[0, 0, 0]}>
            <boxGeometry args={[size * 0.6, size * 0.4, size * 0.6]} />
            <meshStandardMaterial color={color} metalness={0.3} roughness={0.4} />
          </mesh>
          <mesh castShadow position={[0, size * 0.4, 0]}>
            <boxGeometry args={[size * 0.4, size * 0.4, size * 0.4]} />
            <meshStandardMaterial color={color} metalness={0.3} roughness={0.4} />
          </mesh>
        </group>
      );
    
    case 17: // Diamond
      return (
        <group>
          <mesh castShadow position={[0, size * 0.4, 0]}>
            <coneGeometry args={[size * 0.6, size * 0.8, 8]} />
            <meshStandardMaterial color={color} metalness={0.8} roughness={0.1} />
          </mesh>
          <mesh castShadow position={[0, -size * 0.4, 0]} rotation={[Math.PI, 0, 0]}>
            <coneGeometry args={[size * 0.6, size * 0.8, 8]} />
            <meshStandardMaterial color={color} metalness={0.8} roughness={0.1} />
          </mesh>
        </group>
      );
    
    case 18: // Cross
      return (
        <group>
          <mesh castShadow>
            <boxGeometry args={[size * 1.2, size * 0.3, size * 0.3]} />
            <meshStandardMaterial color={color} metalness={0.3} roughness={0.4} />
          </mesh>
          <mesh castShadow>
            <boxGeometry args={[size * 0.3, size * 1.2, size * 0.3]} />
            <meshStandardMaterial color={color} metalness={0.3} roughness={0.4} />
          </mesh>
          <mesh castShadow>
            <boxGeometry args={[size * 0.3, size * 0.3, size * 1.2]} />
            <meshStandardMaterial color={color} metalness={0.3} roughness={0.4} />
          </mesh>
        </group>
      );
    
    case 19: // Hexagonal Prism
      return (
        <mesh castShadow>
          <cylinderGeometry args={[size * 0.5, size * 0.5, size * 0.8, 6]} />
          <meshStandardMaterial color={color} metalness={0.3} roughness={0.4} />
        </mesh>
      );
    
    case 20: // Elongated Sphere
      return (
        <mesh castShadow scale={[1, 1.6, 1]}>
          <sphereGeometry args={[size * 0.5, 16, 16]} />
          <meshStandardMaterial color={color} metalness={0.4} roughness={0.3} />
        </mesh>
      );
    
    case 21: // Flattened Sphere
      return (
        <mesh castShadow scale={[1.4, 0.6, 1.4]}>
          <sphereGeometry args={[size * 0.5, 16, 16]} />
          <meshStandardMaterial color={color} metalness={0.4} roughness={0.3} />
        </mesh>
      );
    
    case 22: // Pentagon Prism
      return (
        <mesh castShadow>
          <cylinderGeometry args={[size * 0.5, size * 0.5, size * 0.9, 5]} />
          <meshStandardMaterial color={color} metalness={0.3} roughness={0.4} />
        </mesh>
      );
    
    case 23: // Thin Torus
      return (
        <mesh castShadow>
          <torusGeometry args={[size * 0.6, size * 0.1, 16, 32]} />
          <meshStandardMaterial color={color} metalness={0.6} roughness={0.2} />
        </mesh>
      );
    
    case 24: // Thick Torus
      return (
        <mesh castShadow>
          <torusGeometry args={[size * 0.4, size * 0.3, 16, 32]} />
          <meshStandardMaterial color={color} metalness={0.5} roughness={0.3} />
        </mesh>
      );
    
    case 25: // Knot
      return (
        <mesh castShadow>
          <torusKnotGeometry args={[size * 0.4, size * 0.12, 64, 8]} />
          <meshStandardMaterial color={color} metalness={0.6} roughness={0.2} />
        </mesh>
      );
    
    case 26: // Twisted Box
      return (
        <mesh castShadow rotation={[0, Math.PI / 4, Math.PI / 6]}>
          <boxGeometry args={[size * 0.8, size * 1.2, size * 0.6]} />
          <meshStandardMaterial color={color} metalness={0.3} roughness={0.4} />
        </mesh>
      );
    
    case 27: // Sphere Cluster
      return (
        <group>
          <mesh castShadow position={[0, 0, 0]}>
            <sphereGeometry args={[size * 0.4, 16, 16]} />
            <meshStandardMaterial color={color} metalness={0.4} roughness={0.3} />
          </mesh>
          <mesh castShadow position={[size * 0.3, 0, 0]}>
            <sphereGeometry args={[size * 0.25, 16, 16]} />
            <meshStandardMaterial color={color} metalness={0.4} roughness={0.3} />
          </mesh>
          <mesh castShadow position={[-size * 0.3, 0, 0]}>
            <sphereGeometry args={[size * 0.25, 16, 16]} />
            <meshStandardMaterial color={color} metalness={0.4} roughness={0.3} />
          </mesh>
        </group>
      );
    
    case 28: // Beveled Cube
      return (
        <mesh castShadow>
          <octahedronGeometry args={[size * 0.65, 1]} />
          <meshStandardMaterial color={color} metalness={0.3} roughness={0.4} />
        </mesh>
      );
    
    case 29: // Tube
      return (
        <mesh castShadow>
          <cylinderGeometry args={[size * 0.5, size * 0.5, size * 1.4, 32, 1, true]} />
          <meshStandardMaterial color={color} metalness={0.5} roughness={0.3} side={THREE.DoubleSide} />
        </mesh>
      );
    
    case 30: // Spiked Sphere
      return (
        <group>
          <mesh castShadow>
            <sphereGeometry args={[size * 0.4, 16, 16]} />
            <meshStandardMaterial color={color} metalness={0.4} roughness={0.3} />
          </mesh>
          {[0, 1, 2, 3].map(i => (
            <mesh key={i} castShadow position={[
              Math.cos((i * Math.PI) / 2) * size * 0.4,
              0,
              Math.sin((i * Math.PI) / 2) * size * 0.4
            ]}>
              <coneGeometry args={[size * 0.1, size * 0.3, 4]} rotation={[0, 0, Math.PI / 2]} />
              <meshStandardMaterial color={color} metalness={0.4} roughness={0.3} />
            </mesh>
          ))}
        </group>
      );
    
    case 31: // Rounded Cone
      return (
        <mesh castShadow>
          <coneGeometry args={[size * 0.6, size * 1.2, 32]} />
          <meshStandardMaterial color={color} metalness={0.4} roughness={0.3} />
        </mesh>
      );
    
    case 32: // Truncated Pyramid
      return (
        <mesh castShadow>
          <cylinderGeometry args={[size * 0.3, size * 0.6, size * 1.0, 4]} />
          <meshStandardMaterial color={color} metalness={0.3} roughness={0.4} />
        </mesh>
      );
    
    case 33: // Double Torus
      return (
        <group>
          <mesh castShadow position={[0, size * 0.2, 0]}>
            <torusGeometry args={[size * 0.4, size * 0.15, 16, 32]} />
            <meshStandardMaterial color={color} metalness={0.5} roughness={0.3} />
          </mesh>
          <mesh castShadow position={[0, -size * 0.2, 0]}>
            <torusGeometry args={[size * 0.4, size * 0.15, 16, 32]} />
            <meshStandardMaterial color={color} metalness={0.5} roughness={0.3} />
          </mesh>
        </group>
      );
    
    case 34: // Rounded Box
      return (
        <mesh castShadow>
          <boxGeometry args={[size * 0.8, size * 0.8, size * 0.8]} />
          <meshStandardMaterial color={color} metalness={0.4} roughness={0.2} />
        </mesh>
      );
    
    case 35: // Cylinder Stack
      return (
        <group>
          <mesh castShadow position={[0, -size * 0.3, 0]}>
            <cylinderGeometry args={[size * 0.5, size * 0.5, size * 0.4, 16]} />
            <meshStandardMaterial color={color} metalness={0.3} roughness={0.4} />
          </mesh>
          <mesh castShadow position={[0, size * 0.1, 0]}>
            <cylinderGeometry args={[size * 0.4, size * 0.4, size * 0.4, 16]} />
            <meshStandardMaterial color={color} metalness={0.3} roughness={0.4} />
          </mesh>
          <mesh castShadow position={[0, size * 0.5, 0]}>
            <cylinderGeometry args={[size * 0.3, size * 0.3, size * 0.4, 16]} />
            <meshStandardMaterial color={color} metalness={0.3} roughness={0.4} />
          </mesh>
        </group>
      );
    
    case 36: // Hollow Sphere
      return (
        <mesh castShadow>
          <sphereGeometry args={[size * 0.6, 16, 16, 0, Math.PI * 2, 0, Math.PI * 0.8]} />
          <meshStandardMaterial color={color} metalness={0.5} roughness={0.3} side={THREE.DoubleSide} />
        </mesh>
      );
    
    case 37: // Gem
      return (
        <mesh castShadow>
          <dodecahedronGeometry args={[size * 0.65]} />
          <meshStandardMaterial color={color} metalness={0.9} roughness={0.05} />
        </mesh>
      );
    
    case 38: // Tri-Cone
      return (
        <group>
          <mesh castShadow position={[0, 0, 0]}>
            <coneGeometry args={[size * 0.4, size * 1.0, 3]} />
            <meshStandardMaterial color={color} metalness={0.3} roughness={0.4} />
          </mesh>
        </group>
      );
    
    case 39: // Spiral (Torus Knot variant)
      return (
        <mesh castShadow>
          <torusKnotGeometry args={[size * 0.35, size * 0.1, 100, 16, 3, 2]} />
          <meshStandardMaterial color={color} metalness={0.6} roughness={0.2} />
        </mesh>
      );
    
    default:
      return (
        <mesh castShadow>
          <sphereGeometry args={[size * 0.6, 16, 16]} />
          <meshStandardMaterial color={color} metalness={0.4} roughness={0.4} />
        </mesh>
      );
  }
}
