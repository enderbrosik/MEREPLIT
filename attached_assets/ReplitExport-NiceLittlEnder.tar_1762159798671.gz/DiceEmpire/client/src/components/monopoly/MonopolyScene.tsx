import { Canvas } from '@react-three/fiber';
import { Suspense } from 'react';
import { Board3D } from './Board3D';
import { PlayerPiece3D } from './PlayerPiece3D';
import { Dice3D } from './Dice3D';
import { CameraController } from './CameraController';
import { useMonopoly } from '@/lib/stores/useMonopoly';

export function MonopolyScene() {
  const players = useMonopoly(state => state.players);
  const boardSpaces = useMonopoly(state => state.boardSpaces);

  return (
    <Canvas
      shadows
      camera={{
        position: [0, 20, 20],
        fov: 50,
        near: 0.1,
        far: 1000,
      }}
      gl={{
        antialias: true,
        powerPreference: 'high-performance',
      }}
    >
      <color attach="background" args={['#87CEEB']} />

      {/* Lighting */}
      <ambientLight intensity={0.5} />
      <directionalLight
        position={[20, 20, 20]}
        intensity={1}
        castShadow
        shadow-mapSize-width={2048}
        shadow-mapSize-height={2048}
        shadow-camera-left={-20}
        shadow-camera-right={20}
        shadow-camera-top={20}
        shadow-camera-bottom={-20}
      />
      <directionalLight position={[-20, 10, -20]} intensity={0.3} />
      <pointLight position={[0, 10, 0]} intensity={0.5} />

      <Suspense fallback={null}>
        {/* Board */}
        <Board3D />

        {/* Player pieces */}
        {players.map((player, index) => {
          const space = boardSpaces[player.position];
          if (!space) return null;

          const playersOnSpace = players.filter(p => p.position === player.position);
          const playerIndex = playersOnSpace.findIndex(p => p.id === player.id);
          const offset = (playerIndex / playersOnSpace.length) * Math.PI * 2;

          return (
            <PlayerPiece3D
              key={player.id}
              player={player}
              position={space.position}
              offset={offset}
            />
          );
        })}

        {/* Dice */}
        <Dice3D />

        {/* Camera */}
        <CameraController />
      </Suspense>

      {/* Ground */}
      <mesh position={[0, -0.5, 0]} receiveShadow rotation={[-Math.PI / 2, 0, 0]}>
        <planeGeometry args={[100, 100]} />
        <meshStandardMaterial color="#228B22" />
      </mesh>
    </Canvas>
  );
}
