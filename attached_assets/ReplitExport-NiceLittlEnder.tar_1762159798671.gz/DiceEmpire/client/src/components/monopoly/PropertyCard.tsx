import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useMonopoly } from '@/lib/stores/useMonopoly';

export function PropertyCard() {
  const showPropertyCard = useMonopoly(state => state.showPropertyCard);
  const boardSpaces = useMonopoly(state => state.boardSpaces);
  const currentPlayerIndex = useMonopoly(state => state.currentPlayerIndex);
  const players = useMonopoly(state => state.players);
  const buyProperty = useMonopoly(state => state.buyProperty);

  if (showPropertyCard === null) return null;

  const space = boardSpaces[showPropertyCard];
  const currentPlayer = players[currentPlayerIndex];

  const handleBuy = () => {
    buyProperty(currentPlayer.id, showPropertyCard);
  };

  const handleSkip = () => {
    useMonopoly.setState({ showPropertyCard: null });
  };

  return (
    <div className="fixed inset-0 flex items-center justify-center bg-black/50 z-50">
      <Card className="w-full max-w-md bg-white shadow-2xl">
        <CardHeader className="text-center" style={{ backgroundColor: space.color || '#f0f0f0' }}>
          <CardTitle className="text-2xl text-white drop-shadow-lg">
            {space.name}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4 p-6">
          <div className="space-y-2">
            <div className="flex justify-between text-lg">
              <span className="font-semibold">Price:</span>
              <span className="text-green-600 font-bold">${space.price}</span>
            </div>
            
            {space.rent && (
              <div className="border-t pt-2">
                <div className="font-semibold mb-2">Rent:</div>
                <div className="space-y-1 text-sm">
                  <div className="flex justify-between">
                    <span>Base Rent:</span>
                    <span>${space.rent[0]}</span>
                  </div>
                  {space.type === 'property' && space.houseCost && (
                    <>
                      <div className="flex justify-between">
                        <span>With 1 House:</span>
                        <span>${space.rent[1]}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>With 2 Houses:</span>
                        <span>${space.rent[2]}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>With 3 Houses:</span>
                        <span>${space.rent[3]}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>With 4 Houses:</span>
                        <span>${space.rent[4]}</span>
                      </div>
                      <div className="flex justify-between font-semibold text-red-600">
                        <span>With Hotel:</span>
                        <span>${space.rent[5]}</span>
                      </div>
                    </>
                  )}
                </div>
              </div>
            )}

            {space.houseCost && (
              <div className="flex justify-between text-sm border-t pt-2">
                <span className="font-semibold">House Cost:</span>
                <span className="text-blue-600">${space.houseCost}</span>
              </div>
            )}
          </div>

          <div className="border-t pt-4">
            <div className="text-center mb-2">
              <span className="font-semibold">Your Money: </span>
              <span className={currentPlayer.money >= (space.price || 0) ? 'text-green-600' : 'text-red-600'}>
                ${currentPlayer.money}
              </span>
            </div>
          </div>

          <div className="flex gap-2">
            <Button
              onClick={handleBuy}
              disabled={currentPlayer.money < (space.price || 0)}
              className="flex-1"
              size="lg"
            >
              Buy Property
            </Button>
            <Button
              onClick={handleSkip}
              variant="outline"
              className="flex-1"
              size="lg"
            >
              Skip
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
